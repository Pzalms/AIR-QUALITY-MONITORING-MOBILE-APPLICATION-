import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:pureair/src/core/aqi_helper.dart';
import 'package:pureair/src/model/aqi.dart';
import 'package:pureair/widgets/pop_up_info_widget.dart';

class PollutantWidget extends StatelessWidget {
  const PollutantWidget({
    Key key,
    @required this.size,
    @required this.title,
    this.backgroundColor,
    this.textColor,
    this.value,
  }) : super(key: key);

  final Size size;
  final String title;
  final Color backgroundColor;
  final Color textColor;
  final dynamic value;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final textTheme = Theme.of(context).textTheme;

    final containerSize = size.shortestSide * 0.159;

    return GestureDetector(
      onTap: () {
        print(title);
        showDialog(
          context: context,
          barrierDismissible: true,
          builder: (context) {
            return PopUpInfoWidget(
              size: size,
              title: title,
            );
          },
        );
      },
      child: Material(
        color: backgroundColor ?? colorScheme.background,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: value.toString().contains('-')
              ? BorderSide.none
              : BorderSide(color: colorScheme.onBackground.withOpacity(0.1)),
        ),
        child: Container(
          height: containerSize.roundToDouble(),
          width: containerSize.roundToDouble(),
          alignment: Alignment.center,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Spacer(),
              Text(
                title.toUpperCase(),
                style: textTheme.bodyText2.copyWith(
                  color: textColor != null
                      ? textColor.withOpacity(0.6)
                      : textTheme.overline.color.withOpacity(0.6),
                  // fontSize: 16,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 2,
                ),
              ),
              Spacer(),
              Text(
                value.toString(),
                maxLines: 1,
                softWrap: true,
                overflow: TextOverflow.ellipsis,
                style: textTheme.headline5.copyWith(
                  color: textColor ?? colorScheme.onBackground,
                  fontWeight: FontWeight.w800,
                ),
              ),
              Spacer(),
            ],
          ),
        ),
      ),
    );
  }
}

class PollutantList extends StatelessWidget {
  const PollutantList({
    Key key,
    @required this.size,
    @required this.model,
  }) : super(key: key);

  final Size size;
  final Aqi model;

  @override
  Widget build(BuildContext context) {
    final iaqi = model.data.iaqi;
    AqiHelper helper = AqiHelper(model);

    return GridView(
      shrinkWrap: true,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 4,
        mainAxisSpacing: 20,
        crossAxisSpacing: 25,
      ),
      primary: false,
      children: <Widget>[
        PollutantWidget(
          size: size,
          title: 'CO',
          value: iaqi.co == null ? '-' : '${iaqi.co.v.round()}',
          backgroundColor: helper.coPollutantBgColor,
          textColor: helper.coTextColor,
        ),
        PollutantWidget(
          size: size,
          title: 'NO\u2082',
          value: iaqi.no2 == null ? '-' : '${iaqi.no2.v.round()}',
          backgroundColor: helper.no2PollutantBgColor,
          textColor: helper.no2TextColor,
        ),
        PollutantWidget(
          size: size,
          title: 'O\u2083',
          value: iaqi.o3 == null ? '-' : '${iaqi.o3.v.round()}',
          backgroundColor: helper.o3PollutantBgColor,
          textColor: helper.o3TextColor,
        ),
        PollutantWidget(
          size: size,
          title: 'PM10',
          value: iaqi.pm10 == null ? '-' : '${iaqi.pm10.v.round()}',
          backgroundColor: helper.pm10PollutantBgColor,
          textColor: helper.pm10TextColor,
        ),
        PollutantWidget(
          size: size,
          title: 'PM2.5',
          value: iaqi.pm25 == null ? '-' : '${iaqi.pm25.v.round()}',
          backgroundColor: helper.pm25PollutantBgColor,
          textColor: helper.pm25TextColor,
        ),
        PollutantWidget(
          size: size,
          title: 'SO\u2082',
          value: iaqi.so2 == null ? '-' : '${iaqi.so2.v.round()}',
          backgroundColor: helper.so2PollutantBgColor,
          textColor: helper.so2TextColor,
        ),
      ],
    );
  }
}
