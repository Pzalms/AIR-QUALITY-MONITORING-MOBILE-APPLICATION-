import 'package:flutter/material.dart';

final appIcon = Image.asset('images/appicon.png');
