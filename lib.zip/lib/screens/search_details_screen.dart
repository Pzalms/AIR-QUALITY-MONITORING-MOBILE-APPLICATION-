import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pureair/blocs/search_details/search_details_bloc.dart';
import 'package:pureair/screens/details_screen.dart';
import 'package:pureair/src/model/search_model/search_data.dart';
import 'package:pureair/widgets/error_screen.dart';
import 'package:pureair/widgets/loading_indicator.dart';

class SearchDetailsScreen extends StatefulWidget {
  const SearchDetailsScreen({Key key, @required this.data}) : super(key: key);

  final SearchData data;

  @override
  _SearchDetailsScreenState createState() => _SearchDetailsScreenState();
}

class _SearchDetailsScreenState extends State<SearchDetailsScreen> {
  SearchDetailsBloc get bloc => BlocProvider.of<SearchDetailsBloc>(context);
  @override
  void initState() {
    final geo = widget.data.station.geo;

    bloc.add(FetchSearchDetails(geo[0], geo[1]));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SearchDetailsBloc, SearchDetailsState>(
      cubit: bloc,
      builder: (context, state) {
        if (state is SearchDetailsLoaded) {
          return DetailsScreen(
            model: state.model,
            situation: state.situation,
            message: state.message,
            pollutants: state.pollutants,
          );
        } else if (state is SearchDetailsLoading) {
          return LoadingIndicator();
        } else {
          return ErrorScreen(
            size: MediaQuery.of(context).size,
            title: 'Please check your internet connection and try again.',
          );
        }
      },
    );
  }
}
