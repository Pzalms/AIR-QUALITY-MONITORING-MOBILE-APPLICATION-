enum Screen { home, search, settings }
