// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'co.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Co _$CoFromJson(Map<String, dynamic> json) {
  return Co(
    v: (json['v'] as num)?.toDouble(),
  );
}

Map<String, dynamic> _$CoToJson(Co instance) => <String, dynamic>{
      'v': instance.v,
    };
