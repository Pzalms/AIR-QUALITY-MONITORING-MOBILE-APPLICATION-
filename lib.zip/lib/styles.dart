import 'package:flutter/material.dart';

class PureAirStyles {
  static final TextStyle splashTitleStyle =
      TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0);

}
